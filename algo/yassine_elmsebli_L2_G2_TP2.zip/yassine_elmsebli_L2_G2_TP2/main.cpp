#include "tp2.h"


int main() {
    tableau p(10);
    p.test(20);
    return 0;
}